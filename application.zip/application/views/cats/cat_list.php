<?php
$this->load->view('cats/head');
$this->load->view('cats/nav');
?>
<body>
<div class="row">
  <div class="col-sm-4"></div>
  <div class="col-sm-8">
    <br>
  </div>
</div> 

    <div class="row">
  <div class="col-sm-4"><?=$this->session->flashdata('msg')?></div>
  <div class="col-sm-8">
  <h4>List Cats</h4>
 
  </div>
</div>
<br>
<div class="row">
  <div class="col-sm-1"></div>
  <div class="col-sm-1">
    <a href="<?=site_url('cats018/add')?>" ><button type="button" class="btn btn-primary">add <i class="fas fa-plus"></i></button></a>
</div>
</div>
<br>
    <div class="container">
         <table class="table table-borderless">
            <thead>
        <tr>
    <th>No</th>
    <th>Name</th>
    <th>Type</th>
    <th>Gender</th>
    <th>Age(Month)</th>
    <th>Price($)</th>
    <th colspan="3">action</th>
</tr>
</div>
<?php $i=1; foreach($cats as $cat) { ?>
    <tr>
        <td><?=$i++?></td>
        <td><?=$cat->name_018?></td>
        <td><?=$cat->type_018?></td>
        <td><?=$cat->gender_018?></td>
        <td><?=$cat->age_018?></td>
        <td><?=$cat->price_018?></td>
        <td><a href="<?=site_url('cats018/edit/'.$cat->id_018)?>"><button type="button" class="btn btn-success"> <i class="fas fa-pen"></i></button></a></td>
        <td><a href="<?=site_url('cats018/delete/'.$cat->id_018)?>" onclick="return confirm('are u sure?')"><button type="button" class="btn btn-danger"><i class="fas fa-trash"></td>
        <td><?php if($cat->sold_018==1) echo 'SOLD'; else { ?><a href="<?=site_url('cats018/sale/'.$cat->id_018)?>"><button type="button" class="btn btn-info">SALE</button></a><?php } ?></td>
      </tr><?php }?>

    </table>
</body>
</html>